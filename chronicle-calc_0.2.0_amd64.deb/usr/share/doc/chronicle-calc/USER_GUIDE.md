# Chronicle Calc — user guide

Version 0.2.0 is a redesigned testing preview, not a production-certified calculator.

## Install the app (not the source)

On a compatible Debian-family x86-64 system, download
`chronicle-calc_0.2.0_amd64.deb`. Open it with your graphical package installer,
or open a terminal in the folder containing the download and run:

```sh
sudo apt install ./chronicle-calc_0.2.0_amd64.deb
```

Then open **Chronicle Calc** from your application menu. The executable is also
available as `chronicle-calc`. You do not need Git, a compiler, Python, Node.js,
Rust, a browser, or a source checkout to run the installed app. GTK and other
system runtime libraries are dependencies; APT can fetch missing dependencies.
The app itself operates offline.

The supplied build is for **Linux x86-64 (Intel/AMD)**, not ARM. Its executable
requires **glibc 2.34 or newer and GTK 3.24 or newer**. It was built and tested
on Debian 13 in this workspace. Ubuntu 22.04+, Linux Mint 21+, and Debian 12+
are intended compatibility targets, not verified test results for this build.
Check the package's actual dependency list before installing on another system.
Fedora/Arch do not use this .deb installation route.

A separate `chronicle-calc-0.2.0-linux-x86_64.tar.gz` contains the same compiled
executable. Extract it and run `./chronicle-calc` in that folder. It needs the
same system GTK/glibc libraries. This archive is **not** an AppImage or Flatpak,
and does not install a menu entry by itself.

## The compact interface

The default view is a 20-button keypad. The top switch turns **Dark mode** on or
off; first-time users start in light mode, while saved preferences are retained.
The toolbar contains History, square root, Copy, and Backspace. F1 opens help.

History replaces the keypad inside the same window. Select a result to reuse it;
**Done**, the History icon, Ctrl+H, or Escape returns to the keypad. There is no
permanent sidebar, branding banner, network badge, or promotional footer.

The **( )** key opens a group or closes an unfinished one after a value. Opening
a group after a value inserts explicit multiplication. Selecting part of an
expression and pressing **( )** wraps that selection. Both parentheses may still
be entered directly from the keyboard.

The window is resizable. Long answers use smaller type and may be truncated at
very small widths; hover for the full result, or use Copy. Error tooltips provide
the full message when it is too long for the display.

## Calculate

Type `128 * 24` and press Enter. Or use the keypad. Results preview while you
type; Enter or the equals button adds the calculation to history. A number
starts a new calculation after a result. An operator continues from the last
full-precision answer using `ans`. Repeated equals does not recalculate.
Click the expression or use arrow keys to edit an existing calculation.

Supported syntax: `+ - * / ^ ( )`, decimals, `sqrt(...)`, `abs(...)`, `pi`, `e`,
and `ans`. Pasted multiplication, division, minus, pi and square-root symbols
are normalized. Functions need parentheses. Use an explicit multiplication
operator: `2 * (3 + 4)`, not `2(3 + 4)`.

`^` means a power and associates right to left: `2^3^2 = 512`.
Powers take precedence over unary minus: `-2^2 = -4`; `(-2)^2 = 4`.
The square-root button operates on the **whole expression**. Type `^2` to square a value.
The plus/minus button negates the whole expression, not only its last term.
Use a decimal point, not a comma or a thousands separator.

**Percent always means divide by 100.** `10% = 0.1`, `200 * 10% = 20`, and
`200 + 10% = 200.1`. For a ten percent increase, use `200 * (1 + 10%)`.
This is deliberately not a contextual business-calculator percent mode.

The result is displayed to up to 16 significant digits. Internally, arithmetic
uses C `long double`, not arbitrary precision or exact symbolic algebra. History
keeps the full serialized internal value; the Copy button copies the displayed,
possibly rounded result. Small binary floating-point rounding errors are possible.
Check important calculations independently.

## Keyboard

| Shortcut | Action |
| --- | --- |
| Enter or `=` | Calculate and save |
| Escape | Close history, or clear the current calculation |
| Ctrl+L | Select the expression |
| Ctrl+Shift+C | Copy the displayed result |
| Ctrl+H | Open or close history in the keypad area |
| Ctrl+D | Switch light / dark mode |
| Ctrl+Q | Quit |
| F1 | Show help |
| Tab / Shift+Tab | Move among controls |
| Space | Activate a focused button |

Normal copy/paste shortcuts work in the expression field. Clipboard contents
are controlled by your desktop; other applications or clipboard managers may
be able to read them.

## History and privacy

Up to 50 calculations, plus your light/dark preference, are saved in:

```text
$XDG_DATA_HOME/chronicle-calc/state.ini
```

When `XDG_DATA_HOME` is unset, the usual path is
`~/.local/share/chronicle-calc/state.ini`. The app creates its directory privately
and saves its file with owner-only permissions (0600). This is not encryption.
Other programs running as your user, backups, or administrators may access it.
Use **History → Clear** to remove the saved list; this is not secure disk erasure.
History is not uploaded. There are no accounts, analytics, remote APIs, or an
application updater. The application code does not make network requests.

The `ans` value starts at zero when the app starts; it is not restored from
history. Click a saved result to reuse it. Long history entries may be visually
shortened; their tooltips show the original text and result.

## Update or uninstall

Install a newer compatible .deb over this one with `sudo apt install ./FILE.deb`.
History remains in your user data directory. To uninstall the app:

```sh
sudo apt remove chronicle-calc
```

Uninstalling the package leaves your user data alone. Clear history in the app
before uninstalling to remove that list. The binary tarball can be removed by
deleting its extracted folder; its saved user data is separate.

## Troubleshooting

- `Exec format error`: check your CPU architecture with `uname -m`; this preview
  is x86_64, not aarch64/ARM.
- `GLIBC_2.34 not found`: the system is older than this executable's baseline.
  Do not replace the system C library manually. Use a build made for your distro.
- A missing GTK library: use the .deb dependency resolver on a supported system,
  or install your distribution's GTK 3 runtime for the standalone binary.
- No graphical display: launch from a Linux graphical desktop. A terminal-only
  SSH session cannot display the window without a configured graphical session.
- Local state cannot be saved: calculations still work for the current session;
  check free disk space and ownership of your user data directory.

The standalone diagnostic command `chronicle-calc --calculate '2+3*4'` prints
`14`. This command is optional; the main product is the graphical app.
